import styled from 'styled-components'

export const BottomContainer = styled.div`
	position: fixed;
	bottom: 24px;
	right: 24px;
`
