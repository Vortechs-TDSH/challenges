import styled from 'styled-components'
import { MenuItem } from '@material-ui/core'

export const Item = styled(MenuItem)`
	padding: 12px 20px !important;
`
