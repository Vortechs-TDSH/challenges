export enum AvailableLanguages {
	ENGLISH = 'en',
	PORTUGUESE = 'pt-BR'
}
