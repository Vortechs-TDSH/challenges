import { ptBrLocales as ptBR } from './pt-BR'

export type ILocale = typeof ptBR
