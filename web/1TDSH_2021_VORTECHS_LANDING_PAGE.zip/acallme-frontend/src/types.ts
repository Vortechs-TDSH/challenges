export type IDate = Date | number
