export * from './Copyright'
export { default } from './Copyright'
