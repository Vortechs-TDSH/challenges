export * from './Image.styled'
