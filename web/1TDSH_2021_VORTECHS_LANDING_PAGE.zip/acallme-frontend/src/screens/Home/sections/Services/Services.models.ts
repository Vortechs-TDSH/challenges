export interface ServicesModel {
	icon: string
	alt: string
}
