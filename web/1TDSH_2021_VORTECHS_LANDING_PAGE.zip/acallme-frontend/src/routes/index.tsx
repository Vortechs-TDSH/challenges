export const HOME = '/'
